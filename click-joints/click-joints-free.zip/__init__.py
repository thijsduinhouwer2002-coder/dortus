"""Click Joints: snijdt een figuur in twee printbare delen met een kogel- of pengewricht."""
import bpy

from . import eigenschappen, exporteer, gesloten, gewricht, meld, paneel, schaal, waaier

MODULES = (eigenschappen, gesloten, gewricht, exporteer, schaal, waaier, paneel, meld)  # meld na paneel: knop onderaan


def register():
    for m in MODULES:
        for k in m.KLASSEN:
            bpy.utils.register_class(k)
    eigenschappen.koppel()
    waaier.koppel()


def unregister():
    waaier.ontkoppel()
    eigenschappen.ontkoppel()
    for m in reversed(MODULES):
        for k in reversed(m.KLASSEN):
            bpy.utils.unregister_class(k)


# Alleen in de direct-zip: maak_zip.sh direct zet dit achter __init__.py (Pro-knoppen op slot, Afkijker 21 nov).
from . import direct as _direct  # noqa: E402

_register_kern, _unregister_kern = register, unregister  # noqa: F821  (fragment achter __init__.py)


def register():  # noqa: F811
    _register_kern()
    _direct.register()


def unregister():  # noqa: F811
    _direct.unregister()
    _unregister_kern()
